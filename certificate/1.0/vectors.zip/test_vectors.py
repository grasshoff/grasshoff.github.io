#!/usr/bin/env python3
"""Replay the test vectors: python3 test_vectors.py (exit 0 when every vector gives its expected result)."""
import json
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
expected = json.loads((HERE / "vectors" / "expected.json").read_text())
bad = 0
for name, want in expected.items():
    out = subprocess.run([sys.executable, "-I", str(HERE / "fc_check.py"), str(HERE / "vectors" / name / "certificate"), "--json"],
                         capture_output=True, text=True)
    rep = json.loads(out.stdout)
    got = sorted(c for c, r in rep["conditions"].items() if r["result"] != "passed")
    ok = rep["state"] == want["state"] and got == want["not_passed"]
    bad += not ok
    print(f"{'ok ' if ok else 'BAD'} {name}: {rep['state']} {got}" + ("" if ok else f"  expected {want}"))
print(f"{len(expected) - bad} of {len(expected)} vectors pass")
sys.exit(1 if bad else 0)
